import 'firebase/firestore';
import firebase from 'firebase';



 const firebaseConfig = {
    apiKey: "AIzaSyBC9nlwucmVEHT92LDQUE1xZ5pRlBOQj70",
    authDomain: "teammates-36c09.firebaseapp.com",
    databaseURL: "https://teammates-36c09.firebaseio.com",
    projectId: "teammates-36c09",
    storageBucket: "teammates-36c09.appspot.com",
    messagingSenderId: "497699383811",
   
  };

  // Initialize Firebase
  if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
  }
export const db = firebase.firestore();
export const auth = firebase.auth();

export default firebase;
