# Login-in-React
Login, account creation and login flow, developed in React.

## Start project 🚀
<!--sec data-title="List files and directories: OS X and Linux" data-id="OSX_Linux_ls" data-collapse=true ces-->

    npm install

<!--endsec-->
<!--sec data-title="List files and directories: OS X and Linux" data-id="OSX_Linux_ls" data-collapse=true ces-->

    npm start

<!--endsec-->

## Default User
<strong>User:</strong> carobsts
</br>
<strong> Password:</strong> 123456

## Demo
https://login-in-react.herokuapp.com/

## Mobile version 📱
<img src="https://i.ibb.co/x2Fpjx6/a.png" alt=''/>
<img src="https://i.ibb.co/ZHdM8RC/b.png" alt=''/>

## Desktop version 💻
<img src="https://i.ibb.co/YXNxnX3/8.png" alt=''/>
<img src="https://i.ibb.co/TMxsv4H/9.png" alt=''/>
<img src="https://i.ibb.co/gwQS6Zy/10.png" alt=''/>
